<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AccountHead;
use Faker\Generator as Faker;

$factory->define(AccountHead::class, function (Faker $faker) {
    return [
        //
    ];
});
