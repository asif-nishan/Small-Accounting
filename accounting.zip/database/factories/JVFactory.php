<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\JV;
use Faker\Generator as Faker;

$factory->define(JV::class, function (Faker $faker) {
    return [
        //
    ];
});
