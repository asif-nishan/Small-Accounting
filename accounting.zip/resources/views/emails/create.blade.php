@component('mail::message')
# All General Ledger Data

<a href="{{asset($data->fileUrl)}}" class="btn btn-large pull-right"><i class="icon-download-alt"> </i> Download </a>



Thanks,<br>
Shadownic Soft.
@endcomponent
