<?php echo e($slot); ?>

<?php /**PATH C:\Projects\php\accounting\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>