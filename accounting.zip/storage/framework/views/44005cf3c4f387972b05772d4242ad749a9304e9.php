<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="main-card mb-6 card">
            <div class="card-body table-responsive">
                <h5 class="card-title">General Ledger</h5>
                <table id="datatable" class="mb-0 table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Ref</th>
                        <th>Details</th>
                        <th>Party</th>
                        <th>D.C</th>
                        <th>Acc. Head</th>

                        <th>CC</th>
                        <th>Acc. Head</th>
                        <th>Amount</th>
                        <th>Remark</th>
                        <th>Pic</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $sl = 1; ?>
                    <?php $__currentLoopData = $jvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $jv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $hasMoreDebit = $jv->hasMoreDebit();
                        $credits = $jv->getCredits();
                        $debits = $jv->getDebits();
                        $getFirstCredit = $jv->getFirstCredit();
                        $getFirstDebit = $jv->getFirstDebit();
                        ?>
                        <?php if(count($debits) == count($credits)): ?>
                            <?php $__currentLoopData = $debits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $debit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($sl); ?></th>
                                    <td><?php echo e(\Carbon\Carbon::parse($jv->date)->format('d-m-Y')); ?></td>
                                    <td><?php echo e($jv->ref); ?></td>
                                    <td><?php echo e($jv->detail); ?></td>
                                    <td><?php echo e($jv->party); ?></td>
                                    <td><?php echo e($debit->accountHead->code); ?></td>
                                    <td><?php echo e($debit->accountHead->name); ?></td>
                                    <td><?php echo e($credits[$key]->accountHead->code); ?></td>
                                    <td><?php echo e($credits[$key]->accountHead->name); ?></td>
                                    <td><?php echo e($debit->debit); ?></td>
                                    
                                    <td><?php echo e($jv->remarks); ?></td>
                                    <td><?php echo e($jv->image_url); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('jvs.edit',$jv->id)); ?>" class="mt-2 btn btn-primary">Edit</a>
                                    </td>
                                </tr>
                                <?php $sl++?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $jv->jvItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $jvItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if(count($debits) > count($credits)): ?>
                                        <?php if($getFirstCredit != null): ?>
                                            <?php if($getFirstCredit->id == $jvItem->id): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <th scope="row"><?php echo e($sl); ?></th>
                                        <td><?php echo e(\Carbon\Carbon::parse($jv->date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($jv->ref); ?></td>
                                        <td><?php echo e($jv->detail); ?></td>
                                        <td><?php echo e($jv->party); ?></td>
                                        <td><?php echo e($jvItem->accountHead->code); ?></td>
                                        <td><?php echo e($jvItem->accountHead->name); ?></td>

                                        <td><?php echo e($getFirstCredit !=null? $getFirstCredit->accountHead->code :''); ?></td>
                                        <td><?php echo e($getFirstCredit !=null? $getFirstCredit->accountHead->name:''); ?>

                                            <td><?php echo e($jvItem->debit); ?></td>
                                        
                                        <td><?php echo e($jv->remarks); ?></td>
                                        <td><?php echo e($jv->image_url); ?></td>
                                    <?php else: ?>
                                        <?php if($getFirstDebit != null): ?>
                                            <?php if($getFirstDebit->id == $jvItem->id): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <th scope="row"><?php echo e($sl); ?></th>
                                        <td><?php echo e(\Carbon\Carbon::parse($jvItem->date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($jv->ref); ?></td>
                                        <td><?php echo e($jv->detail); ?></td>
                                        <td><?php echo e($jv->party); ?></td>
                                        <td><?php echo e($getFirstDebit !=null? $getFirstDebit->accountHead->code :''); ?></td>
                                        <td><?php echo e($getFirstDebit !=null? $getFirstDebit->accountHead->name:''); ?></td>
                                        
                                        <td><?php echo e($jvItem->accountHead->code); ?></td>
                                        <td><?php echo e($jvItem->accountHead->name); ?></td>
                                        <td><?php echo e($jvItem->credit); ?></td>
                                        <td><?php echo e($jv->remarks); ?></td>
                                        <td><?php echo e($jv->image_url); ?></td>
                                    <?php endif; ?>

                                    <td>
                                        <a href="<?php echo e(route('jvs.edit',$jv->id)); ?>" class="mt-2 btn btn-primary">Edit</a>
                                    </td>
                                    <?php $sl++?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/accounting/resources/views/general_ledgers/index.blade.php ENDPATH**/ ?>