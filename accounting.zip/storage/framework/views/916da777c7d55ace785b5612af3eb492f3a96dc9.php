<?php $__env->startSection('content'); ?>
    <div class="main-card mb-3 card">
        <div class="card-body">
            <?php if(isset($title)): ?>
                <h5 class="card-title"><?php echo e($title); ?></h5>
            <?php endif; ?>
            <form class="" action="<?php echo e(route('general-ledgers.sendPost')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="position-relative form-group">
                    <label for="email" class="">Email</label>
                    <input required name="email" id="email" placeholder="" type="email" value="<?php echo e(old('email')); ?>"
                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <em class="error invalid-feedback"><?php echo e($errors->first('email')); ?>

                    </em>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="position-relative form-group">
                    <input type="submit" value="Send" class="mt-2 btn btn-primary">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/accounting/resources/views/general_ledgers/send.blade.php ENDPATH**/ ?>