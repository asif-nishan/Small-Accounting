
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="main-card mb-6 card">
            <div class="card-body table-responsive">
                <h5 class="card-title">General Ledger</h5>
                <table id="datatable" class="mb-0 table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Ref</th>
                        <th>Details</th>
                        <th>Party</th>
                        <th>D.C</th>
                        <th>Acc. Head</th>
                        <th>D.A.</th>
                        <th>CC</th>
                        <th>Acc. Head</th>
                        <th>C.A</th>
                        <th>Remark</th>
                        <th>Pic</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $jvItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $jvItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e(\Carbon\Carbon::parse($jvItem->date)->format('d-m-Y')); ?></td>
                            <td><?php echo e($jvItem->jv->ref); ?></td>
                            <td><?php echo e($jvItem->jv->details); ?></td>
                            <td><?php echo e($jvItem->jv->party); ?></td>
                            <?php if($jvItem->debit == 0): ?>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php else: ?>
                                <td><?php echo e($jvItem->accountHead->code); ?></td>
                                <td><?php echo e($jvItem->accountHead->name); ?></td>
                                <td><?php echo e($jvItem->debit); ?></td>
                            <?php endif; ?>
                            <?php if($jvItem->credit == 0): ?>
                                <td></td>
                                <td></td>
                                <td></td>
                            <?php else: ?>
                                <td><?php echo e($jvItem->accountHead->code); ?></td>
                                <td><?php echo e($jvItem->accountHead->name); ?></td>
                                <td><?php echo e($jvItem->credit); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($jvItem->jv->remark); ?></td>
                            <td><?php echo e($jvItem->jv->image_url); ?></td>
                            <td>
                                <a href="#" class="mt-2 btn btn-primary">Edit</a>
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\php\accounting\resources\views/general_ledgers/index.blade.php ENDPATH**/ ?>