<h3>The general ledger is attached.</h3>
<?php /**PATH /home/vagrant/code/accounting/resources/views/emails/report.blade.php ENDPATH**/ ?>