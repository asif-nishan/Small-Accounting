<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Accounting</title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"/>
    <meta name="msapplication-tap-highlight" content="no">
    <?php echo $__env->yieldContent('meta'); ?>

    
    <link href="<?php echo e(asset('assets/main.css')); ?>" rel="stylesheet">


    <?php echo $__env->yieldContent('css'); ?>

</head>
<body>
<div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
    
    <div class="app-header header-shadow bg-vicious-stance header-text-light">
        <div class="app-header__logo">
            <div class="logo-src"></div>
            <div class="header__pane ml-auto">
                <div>
                    <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                            data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                    </button>
                </div>
            </div>
        </div>
        <div class="app-header__mobile-menu">
            <div>
                <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                </button>
            </div>
        </div>
        <div class="app-header__menu">
                <span>
                    <button type="button"
                            class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
        </div>
        <div class="app-header__content">
            <div class="app-header-right">
                <div class="header-btn-lg pr-0">
                    <div class="widget-content p-0">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="btn-group">
                                    <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                       class="p-0 btn">
                                        <img width="42" class="rounded-circle"
                                             src="<?php echo e(asset('assets/images/avatars/dummy.jpg')); ?>"
                                             alt="">
                                        <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                    </a>
                                    <div tabindex="-1" role="menu" aria-hidden="true"
                                         class="dropdown-menu dropdown-menu-right">
                                        <button type="button" tabindex="0" class="dropdown-item">User Account</button>
                                        <button type="button" tabindex="0" class="dropdown-item">Settings</button>
                                        
                                        <div tabindex="-1" class="dropdown-divider"></div>
                                        <a href="/logout" class="dropdown-item">Logout</a>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content-left  ml-3 header-user-info">
                                <div class="widget-heading">
                                    <?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>

                                </div>
                                <div class="widget-subheading">
                                    <?php echo e(\Illuminate\Support\Facades\Auth::user()->email); ?>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="ui-theme-settings">
        <button type="button" id="TooltipDemo" class="btn-open-options btn btn-warning">
            <i class="fa fa-cog fa-w-16 fa-spin fa-2x"></i>
        </button>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </div>
    <div class="app-main">
        
        
        <div class="app-sidebar sidebar-shadow bg-vicious-stance sidebar-text-light">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                                data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                        <span>
                            <button type="button"
                                    class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
            </div>
            <div class="scrollbar-sidebar">
                <div class="app-sidebar__inner mt-2">
                    <ul class="vertical-nav-menu">
                        <li>
                            <a href="/" class="<?php echo e(Request::is('/') ? 'mm-active' : ''); ?>">
                                <i class="metismenu-icon pe-7s-rocket"></i>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="/general-ledgers" class="<?php echo e(Request::is('general-ledgers') ? 'mm-active' : ''); ?>">
                                <i class="metismenu-icon pe-7s-wallet"></i>
                                General Ledger
                            </a>
                        </li>
                        <?php if(Request::path() =='jvs' || Request::path() =='jvs/create'): ?>
                            <li class="mm-active">
                        <?php else: ?>
                            <li>
                                <?php endif; ?>
                                <a href="#">
                                    <i class="metismenu-icon pe-7s-cash"></i>
                                    JV
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                </a>
                                <ul>
                                    <li>
                                        <a href="/jvs/create"
                                           class="<?php echo e(Request::path() =='products/stocks' ? 'mm-active' : ''); ?>">
                                            <i class="metismenu-icon">
                                            </i>Create JV
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/jvs"
                                           class="<?php echo e(Request::path() =='jvs' ? 'mm-active' : ''); ?>">
                                            <i class="metismenu-icon">
                                            </i>JV List
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <?php if(Request::path() =='account-heads' || Request::path() =='account-heads/create'): ?>
                                <li class="mm-active">
                            <?php else: ?>
                                <li>
                                    <?php endif; ?>
                                    <a href="#">
                                        <i class="metismenu-icon pe-7s-bookmarks"></i>
                                        Charts of account
                                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                                    </a>
                                    <ul>
                                        <li>
                                            <a href="/account-heads/create"
                                               class="<?php echo e(Request::path() =='account-heads/create' ? 'mm-active' : ''); ?>">
                                                <i class="metismenu-icon">
                                                </i>New Account head
                                            </a>
                                        </li>
                                        <li>
                                            <a href="/account-heads"
                                               class="<?php echo e(Request::path() =='account-heads' ? 'mm-active' : ''); ?>">
                                                <i class="metismenu-icon">
                                                </i>Chart of Account
                                            </a>
                                        </li>
                                    </ul>
                                </li>

                                <li>
                                    <a href="/general-ledgers/send"
                                       class="<?php echo e(Request::is('general-ledgers/send') ? 'mm-active' : ''); ?>">
                                        <i class="metismenu-icon pe-7s-mail"></i>
                                        Email Excel FIle
                                    </a>
                                </li>
                                <li>
                                    <a onclick="location.reload()">
                                        <i class="metismenu-icon pe-7s-refresh"></i>
                                        Reload
                                    </a>
                                </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="app-main__outer">
            <div class="app-main__inner">
                <?php if(Session::has('message')): ?>
                    <div class="col-12">
                        <div class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?> alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php echo e(Session::get('message')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <?php if(isset($title)): ?>
                    
                    
                    
                    
                    
                    

                    
                    
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="app-wrapper-footer">
                <div class="app-footer">
                    <div class="app-footer__inner">
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="app-footer-right">

                            <ul class="nav">

                                <li class="nav-item">

                                    <a target="_blank" href="https://www.shadownicsoft.com/" class="nav-link">
                                        Maintain And Developed By Shadownicsoft
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo e(asset('assets/scripts/main.js')); ?>"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\Projects\php\accounting\resources\views/layouts/layout.blade.php ENDPATH**/ ?>